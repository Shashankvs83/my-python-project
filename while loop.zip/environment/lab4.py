awsrestart = {
    "anmol" : "trainer",
    "shash" : "student",
}
print(awsrestart)
print(type(awsrestart))
print(awsrestart["anmol"])
