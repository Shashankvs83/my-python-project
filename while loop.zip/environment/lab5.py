mixedtypelist = [45,26,"shashu","78"]
for item in mixedtypelist :
    print("{} is of the data type {}" .format(item,type(item)))