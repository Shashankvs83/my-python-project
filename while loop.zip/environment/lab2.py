a=3
print(a)
print(type(a))
print(str(a) + " is a data type " + str(type(a)) + str(int(5345)))